﻿namespace P03_FootballBetting.Data
{
    public class Configuring
    {
        public const string ConnectionString = @"Server=DESKTOP-CP2NEHV\SQLEXPRESS;Database=FootballBookmakerSystem;Integrated Security=True";
    }
}