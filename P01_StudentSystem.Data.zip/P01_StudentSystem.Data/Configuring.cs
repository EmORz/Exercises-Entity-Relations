﻿namespace P01_StudentSystem.Data
{
    public class Configuring
    {
        public const string ConnectionString = @"Server=DESKTOP-CP2NEHV\SQLEXPRESS;Database=StudentSystem;Integrated Security=True";
    }
}