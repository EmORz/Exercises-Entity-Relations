﻿namespace P01_StudentSystem.Data.Models.Enum
{
    public enum ResourceType
    {
        Video,
        Presentation,
        Document ,
        Other
    }
}